document.getElementById("nav").innerHTML = 
'<a href="#">Home</a>';

document.getElementById("nav").innerHTML += 
'<a href="#">Products</a>';

document.getElementById("nav").innerHTML += 
'<a href="#">Services</a>';

document.getElementById("nav").innerHTML += 
'<a href="#">Contacts</a>';


