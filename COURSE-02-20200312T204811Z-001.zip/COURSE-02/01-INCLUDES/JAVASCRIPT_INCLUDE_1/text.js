
document.getElementById("nav").innerHTML = 
"Here is text included using JavaScript.";
